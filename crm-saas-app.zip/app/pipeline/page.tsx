"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { Separator } from "@/components/ui/separator"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, DollarSign, Calendar } from "lucide-react"

const pipelineStages = [
  { id: "qualified", name: "Qualified", color: "bg-blue-100 border-blue-200" },
  { id: "proposal", name: "Proposal", color: "bg-yellow-100 border-yellow-200" },
  { id: "negotiation", name: "Negotiation", color: "bg-orange-100 border-orange-200" },
  { id: "closed-won", name: "Closed Won", color: "bg-green-100 border-green-200" },
]

const deals = [
  {
    id: 1,
    title: "Enterprise Software License",
    company: "TechCorp Inc",
    value: 75000,
    stage: "qualified",
    probability: 25,
    closeDate: "2024-03-15",
    contact: "Alice Johnson",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 2,
    title: "Cloud Migration Project",
    company: "Innovate Solutions",
    value: 120000,
    stage: "proposal",
    probability: 60,
    closeDate: "2024-02-28",
    contact: "Bob Smith",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 3,
    title: "Digital Transformation",
    company: "StartupIO",
    value: 95000,
    stage: "negotiation",
    probability: 80,
    closeDate: "2024-02-20",
    contact: "Carol Davis",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 4,
    title: "Security Audit Service",
    company: "Enterprise Corp",
    value: 45000,
    stage: "closed-won",
    probability: 100,
    closeDate: "2024-01-30",
    contact: "David Wilson",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 5,
    title: "Mobile App Development",
    company: "Growth Inc",
    value: 85000,
    stage: "qualified",
    probability: 30,
    closeDate: "2024-04-10",
    contact: "Emma Brown",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 6,
    title: "Data Analytics Platform",
    company: "Analytics Pro",
    value: 150000,
    stage: "proposal",
    probability: 50,
    closeDate: "2024-03-25",
    contact: "Frank Miller",
    avatar: "/placeholder.svg?height=32&width=32",
  },
]

export default function PipelinePage() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)

  const getDealsByStage = (stageId: string) => {
    return deals.filter((deal) => deal.stage === stageId)
  }

  const getStageTotal = (stageId: string) => {
    return getDealsByStage(stageId).reduce((total, deal) => total + deal.value, 0)
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <SidebarInset>
      <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
        <SidebarTrigger className="-ml-1" />
        <Separator orientation="vertical" className="mr-2 h-4" />
        <h1 className="text-lg font-semibold">Sales Pipeline</h1>
      </header>
      <div className="flex-1 p-4 pt-6">
        {/* Header Actions */}
        <div className="flex items-center justify-between mb-6">
          <div className="space-y-1">
            <h2 className="text-2xl font-bold tracking-tight">Pipeline Overview</h2>
            <p className="text-muted-foreground">Manage your deals through the sales process</p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Deal
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Add New Deal</DialogTitle>
                <DialogDescription>Create a new deal in your sales pipeline.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="deal-title" className="text-right">
                    Title
                  </Label>
                  <Input id="deal-title" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="company" className="text-right">
                    Company
                  </Label>
                  <Input id="company" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="value" className="text-right">
                    Value
                  </Label>
                  <Input id="value" type="number" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="stage" className="text-right">
                    Stage
                  </Label>
                  <Select>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select stage" />
                    </SelectTrigger>
                    <SelectContent>
                      {pipelineStages.map((stage) => (
                        <SelectItem key={stage.id} value={stage.id}>
                          {stage.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="close-date" className="text-right">
                    Close Date
                  </Label>
                  <Input id="close-date" type="date" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="notes" className="text-right">
                    Notes
                  </Label>
                  <Textarea id="notes" className="col-span-3" />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" onClick={() => setIsAddDialogOpen(false)}>
                  Add Deal
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Kanban Board */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {pipelineStages.map((stage) => (
            <div key={stage.id} className="space-y-4">
              <div className={`rounded-lg border-2 border-dashed p-4 ${stage.color}`}>
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{stage.name}</h3>
                  <Badge variant="secondary">{getDealsByStage(stage.id).length}</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">{formatCurrency(getStageTotal(stage.id))}</p>
              </div>

              <div className="space-y-3">
                {getDealsByStage(stage.id).map((deal) => (
                  <Card key={deal.id} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">{deal.title}</CardTitle>
                      <CardDescription className="text-xs">{deal.company}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-1 text-xs">
                          <DollarSign className="h-3 w-3" />
                          <span className="font-medium">{formatCurrency(deal.value)}</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {deal.probability}%
                        </Badge>
                      </div>

                      <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        <span>{new Date(deal.closeDate).toLocaleDateString()}</span>
                      </div>

                      <div className="flex items-center space-x-2 pt-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={deal.avatar || "/placeholder.svg"} />
                          <AvatarFallback className="text-xs">
                            {deal.contact
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-muted-foreground">{deal.contact}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </SidebarInset>
  )
}
