"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { Separator } from "@/components/ui/separator"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Send, Inbox, Archive, Star, Reply, Forward, Trash2, Search, Plus, Paperclip } from "lucide-react"

const emails = [
  {
    id: 1,
    from: "Alice Johnson",
    email: "alice@techcorp.com",
    subject: "Follow-up on Enterprise Software License",
    preview: "Thank you for the demo yesterday. We're very interested in moving forward...",
    time: "2 hours ago",
    read: false,
    starred: true,
    avatar: "/placeholder.svg?height=32&width=32",
    type: "inbox",
  },
  {
    id: 2,
    from: "Bob Smith",
    email: "bob@innovate.com",
    subject: "Cloud Migration Timeline",
    preview: "Could we schedule a call to discuss the project timeline and milestones?",
    time: "5 hours ago",
    read: true,
    starred: false,
    avatar: "/placeholder.svg?height=32&width=32",
    type: "inbox",
  },
  {
    id: 3,
    from: "Carol Davis",
    email: "carol@startup.io",
    subject: "Contract Review Complete",
    preview: "We've completed our review of the contract. Just a few minor changes...",
    time: "1 day ago",
    read: true,
    starred: false,
    avatar: "/placeholder.svg?height=32&width=32",
    type: "inbox",
  },
  {
    id: 4,
    from: "You",
    email: "you@company.com",
    subject: "Proposal for Digital Transformation",
    preview: "Please find attached our comprehensive proposal for your digital transformation project...",
    time: "2 days ago",
    read: true,
    starred: false,
    avatar: "/placeholder.svg?height=32&width=32",
    type: "sent",
  },
]

export default function EmailPage() {
  const [selectedEmail, setSelectedEmail] = useState(emails[0])
  const [isComposeOpen, setIsComposeOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("inbox")

  const getFilteredEmails = (type: string) => {
    if (type === "starred") {
      return emails.filter((email) => email.starred)
    }
    return emails.filter((email) => email.type === type)
  }

  return (
    <SidebarInset>
      <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
        <SidebarTrigger className="-ml-1" />
        <Separator orientation="vertical" className="mr-2 h-4" />
        <h1 className="text-lg font-semibold">Email</h1>
      </header>
      <div className="flex-1 p-4 pt-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search emails..." className="pl-8 w-[300px]" />
            </div>
          </div>
          <Dialog open={isComposeOpen} onOpenChange={setIsComposeOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Compose
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Compose Email</DialogTitle>
                <DialogDescription>Send a new email to your contacts.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="to" className="text-right">
                    To
                  </Label>
                  <Input id="to" placeholder="recipient@example.com" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="subject" className="text-right">
                    Subject
                  </Label>
                  <Input id="subject" className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <Label htmlFor="message" className="text-right pt-2">
                    Message
                  </Label>
                  <Textarea id="message" className="col-span-3 min-h-[200px]" placeholder="Type your message here..." />
                </div>
              </div>
              <DialogFooter className="flex justify-between">
                <Button variant="outline">
                  <Paperclip className="mr-2 h-4 w-4" />
                  Attach
                </Button>
                <div className="space-x-2">
                  <Button variant="outline" onClick={() => setIsComposeOpen(false)}>
                    Save Draft
                  </Button>
                  <Button onClick={() => setIsComposeOpen(false)}>
                    <Send className="mr-2 h-4 w-4" />
                    Send
                  </Button>
                </div>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Email List */}
          <div className="lg:col-span-1">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="inbox" className="flex items-center gap-2">
                  <Inbox className="h-4 w-4" />
                  Inbox
                </TabsTrigger>
                <TabsTrigger value="sent" className="flex items-center gap-2">
                  <Send className="h-4 w-4" />
                  Sent
                </TabsTrigger>
                <TabsTrigger value="starred" className="flex items-center gap-2">
                  <Star className="h-4 w-4" />
                  Starred
                </TabsTrigger>
              </TabsList>

              <TabsContent value={activeTab} className="mt-4">
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {getFilteredEmails(activeTab).map((email) => (
                    <Card
                      key={email.id}
                      className={`cursor-pointer transition-colors hover:bg-muted/50 ${
                        selectedEmail.id === email.id ? "bg-muted" : ""
                      }`}
                      onClick={() => setSelectedEmail(email)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={email.avatar || "/placeholder.svg"} />
                            <AvatarFallback>
                              {email.from
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className={`text-sm font-medium truncate ${!email.read ? "font-bold" : ""}`}>
                                {email.from}
                              </p>
                              <div className="flex items-center space-x-1">
                                {email.starred && <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />}
                                <span className="text-xs text-muted-foreground">{email.time}</span>
                              </div>
                            </div>
                            <p
                              className={`text-sm truncate ${!email.read ? "font-semibold" : "text-muted-foreground"}`}
                            >
                              {email.subject}
                            </p>
                            <p className="text-xs text-muted-foreground truncate mt-1">{email.preview}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Email Content */}
          <div className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader className="border-b">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="text-lg">{selectedEmail.subject}</CardTitle>
                    <div className="flex items-center space-x-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={selectedEmail.avatar || "/placeholder.svg"} />
                        <AvatarFallback className="text-xs">
                          {selectedEmail.from
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm text-muted-foreground">
                        {selectedEmail.from} {"<"}
                        {selectedEmail.email}
                        {">"}
                      </span>
                      <Badge variant="outline" className="text-xs">
                        {selectedEmail.time}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm">
                      <Star className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Archive className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="prose max-w-none">
                  <p>{selectedEmail.preview}</p>
                  <p className="mt-4">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                    aliquip ex ea commodo consequat.
                  </p>
                  <p className="mt-4">
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                    pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit
                    anim id est laborum.
                  </p>
                  <p className="mt-4">
                    Best regards,
                    <br />
                    {selectedEmail.from}
                  </p>
                </div>
              </CardContent>
              <div className="border-t p-4">
                <div className="flex items-center space-x-2">
                  <Button>
                    <Reply className="mr-2 h-4 w-4" />
                    Reply
                  </Button>
                  <Button variant="outline">
                    <Forward className="mr-2 h-4 w-4" />
                    Forward
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </SidebarInset>
  )
}
